import os
import time
import torch
import lpips
import kornia
from torch import nn, Tensor
import torchvision
import numpy as np
from torchvision import transforms
from tqdm import tqdm
from torch.utils.data import Dataset, DataLoader
from utils.Dataloader import Dataset
from network.Noise import Noise
from network.model import Models, init_model
from network.Unet_common import DWT, IWT
import config as c
from network.noise_layers import JpegTest, C, C1, SP, HF, VF, R, P, RC, RS, Identity

from torchmetrics.image import PeakSignalNoiseRatio
from torchmetrics.image import StructuralSimilarityIndexMeasure
from focal_frequency_loss import FocalFrequencyLoss as ffl

harr=True
bias=True
H=1024#1024
W=1024#1024
dataset_path = "....../Datasets/DIV2K/"
dataset_train_path =  "DIV2K_train_HR/" #DIV2K_train_HR  DIV2K_train_HR_16
dataset_valid_path =  "DIV2K_valid_HR16/" #DIV2K_valid_HR   DIV2K_valid_HR_16
dataset_test_path =  "DIV2K_valid_HR1/"

# DIV2K_COCO_train

train_dataset = Dataset(os.path.join(dataset_path, dataset_train_path), H, W)
train_dataloader = DataLoader(train_dataset, batch_size=c.batch_size_train, shuffle=True, num_workers=min(8, os.cpu_count()//2), pin_memory=True)
valid_dataset = Dataset(os.path.join(dataset_path, dataset_valid_path), H, W)
valid_dataloader = DataLoader(valid_dataset, batch_size=1, shuffle=False, num_workers=min(8, os.cpu_count()//2), pin_memory=True)
test_dataset = Dataset(os.path.join(dataset_path, dataset_test_path), H, W)
test_dataloader = DataLoader(test_dataset, batch_size=1, shuffle=False, num_workers=min(8, os.cpu_count()//2), pin_memory=True)
dwt = DWT()
iwt = IWT()
transform = transforms.Compose([transforms.Resize((c.model_input_HW, c.model_input_HW))])
criterion_MSE = nn.MSELoss()



def run_model(result_folder, step, strength=1.0, dataloader=None, net=None, optim=None, perceived_attack=None, attack=None, i_epoch=None, epoch=None, mode='train'):
    lr = None
    if mode == 'train':
        progress = tqdm(dataloader, desc=f'Epoch {i_epoch}/{epoch} [Train]')
        batch_size =c.batch_size_train
        net.train()
    elif mode == 'valid':
        progress = tqdm(dataloader, desc=f'Epoch {i_epoch}/{epoch} [Valid]')
        batch_size =1
        net.eval()
    elif mode == 'test' or mode == 'test_all':
        progress = tqdm(dataloader, desc=f'Epoch {i_epoch}/{epoch} [Test]')
        batch_size =1
        net.eval()

    total_loss = []
    total_ber = []
    total_psnrc = []
    total_ssimc = []
    total_psnrs = []
    total_ssims = []
    if step == 0:
        for i in progress:
            secret = torch.Tensor(np.random.choice([0, 1], (batch_size, c.watermark_length))).to(c.device)
            watermark_map = net.model_wtoi(secret)
            # watermark_map_HW = (transforms.Resize([H, W])(watermark_map.to(c.device)))
            watermark_map_attack = perceived_attack([watermark_map, watermark_map])
            watermark_map_attack = transform(watermark_map_attack)
            secret_inv = net.model_itow(watermark_map_attack)
            if mode == 'train':
                optim.zero_grad()
            loss_decoding = criterion_MSE(secret_inv, secret)
            ber_perceived = decoded_message_error_rate_batch(secret_inv, secret)
            loss = loss_decoding
            if optim is None:
                lr = None
            else:
                lr = np.log10(optim.param_groups[0]['lr'])
            if mode == 'train':
                if i==0:
                    image = torch.cat((watermark_map[0:1], watermark_map_attack[0:1]),dim=3)
                    torchvision.utils.save_image(image, result_folder + f"train_results/step{step}/train_w_watt.png")
                loss.backward()
                optim.step()

            elif mode == 'valid':
                if i==0:
                    image = torch.cat((watermark_map[0:1], watermark_map_attack[0:1]), dim=3)
                    torchvision.utils.save_image(image, result_folder + f"train_results/step{step}/valid_w_watt.png")
            elif mode == 'test' or mode == 'test_all':
                if i==0:
                    image = torch.cat((watermark_map[0:1], watermark_map_attack[0:1]), dim=3)
                    torchvision.utils.save_image(image, result_folder + f"train_results/step{step}/test_w_watt.png")
            total_loss.append(loss.item())
            total_ber.append(ber_perceived)

        avg_loss = sum(total_loss) / len(total_loss)
        avg_ber =  sum(total_ber) / len(total_ber)
        avg_psnrc=0
        avg_psnrs=0
        avg_ssimc=0
        avg_ssims=0
        return lr, avg_loss, avg_ber, avg_psnrc, avg_ssimc, avg_psnrs, avg_ssims
    else:
        for i, batch in enumerate(progress):
            inputs = batch.to(c.device)
            if c.arbitrary_resolution:
                inputs = perceived_attack([inputs, inputs])
            resize_inputs = transform(inputs)
            secret = torch.Tensor(np.random.choice([0, 1], (inputs.shape[0], c.watermark_length))).to(c.device)
            watermark_map = net.model_wtoi(secret)

            # ##########
            # watermark_map_HW = (transforms.Resize([H, W])(watermark_map.to(c.device)))
            # watermark_map_attack = perceived_attack([watermark_map_HW, watermark_map_HW])
            # watermark_map_attack = transform(watermark_map_attack)
            # secret_inv = net.model_itow(watermark_map_attack)
            # print(decoded_message_error_rate_batch(secret_inv, secret))
            # ##########
            if harr:
                cover_input = dwt(resize_inputs)
                secret_input = dwt(watermark_map)
            else:
                cover_input = resize_inputs
                secret_input = watermark_map
            forward_input = torch.cat((cover_input, secret_input), 1)

            forward_output = net.model_inn(forward_input)
            output_z_guass = gauss_noise(forward_output.narrow(1, forward_output.shape[1] // 2, forward_output.shape[1] // 2).shape)
            encoded_output = forward_output.narrow(1, 0, forward_output.shape[1] // 2)
            if harr:
                encoded_output = iwt(encoded_output)
            else:
                encoded_output = encoded_output
            controlled_diff = (transforms.Resize(inputs.shape[-2:])(encoded_output.to(c.device) - resize_inputs)) * strength
            output = torch.clamp(inputs + controlled_diff, min=-1.0, max=1.0)
            #######################################################################################################
            output_attack = attack([output, output])
            trans_images = transform(output_attack)
            if harr:
                trans_images = dwt(trans_images)
            else:
                trans_images = trans_images

            backward_input = torch.cat((trans_images, output_z_guass.to(c.device)), 1)
            backward_output = net.model_inn(backward_input, rev=True)
            decoded_watermark = backward_output.narrow(1, backward_output.shape[1]//2, backward_output.shape[1]//2)
            if harr:
                decoded_watermark = iwt(decoded_watermark)
            else:
                decoded_watermark = decoded_watermark

            decoded_secret = net.model_itow(decoded_watermark.to(c.device))
            ber = decoded_message_error_rate_batch(decoded_secret, secret)
            # psnrc = image_psnr(output.detach().cpu(), inputs.cpu())
            # ssimc = image_ssim(output.detach().cpu(), inputs.cpu())
            # psnrs = image_psnr(decoded_watermark.detach().cpu(), watermark_map.cpu())
            # ssims = image_ssim(decoded_watermark.detach().cpu(), watermark_map.cpu())

            psnrc = kornia.losses.psnr_loss(output.detach().to(c.device), inputs.to(c.device), 2).item()
            ssimc = 1 - 2 * kornia.losses.ssim_loss(output.detach().to(c.device), inputs.to(c.device), window_size=5, reduction="mean").item()
            psnrs = kornia.losses.psnr_loss(decoded_watermark.detach().to(c.device), watermark_map.to(c.device), 2).item()
            ssims = 1 - 2 * kornia.losses.ssim_loss(decoded_watermark.detach().to(c.device), watermark_map.to(c.device), window_size=5, reduction="mean").item()

            if mode == 'train':
                optim.zero_grad()


            loss_encoding = criterion_MSE(encoded_output.to(c.device), resize_inputs)
            loss_decoding = criterion_MSE(decoded_secret, secret)
            if step == 1:
                loss = c.lamda_encoding * loss_encoding + c.lamda_decoding * loss_decoding
            elif step == 2:
                loss = c.lamda_encoding * loss_encoding + c.lamda_decoding_step2 * loss_decoding

            # if c.vggloss:
            #     loss_encoding1 = criterion_lpips(encoded_output.to(c.device), resize_inputs).mean()  # 或者 .sum()
            # else:
            #     loss_encoding1=0
            # if c.fflloss:
            #     loss_encoding2 = criterion_ffl(encoded_output.to(c.device), resize_inputs).mean()
            # else:
            #     loss_encoding2=0
            # if c.pre_decoding:
            #     loss_decoding1 = criterion_MSE(decoded_watermark.to(c.device), watermark_map)
            # else:
            #     loss_decoding1=0
            # if step == 1:
            #     loss = c.lamda_encoding * loss_encoding + c.lamda_encoding1 * loss_encoding1 + c.lamda_encoding2 * loss_encoding2 + c.lamda_decoding1 * loss_decoding1 + c.lamda_decoding * loss_decoding
            # elif step == 2:
            #     loss = c.lamda_encoding * loss_encoding + c.lamda_encoding1 * loss_encoding1 + c.lamda_encoding2 * loss_encoding2 + c.lamda_decoding1 * loss_decoding1 + c.lamda_decoding_step2 * loss_decoding


            # print(loss_encoding, loss_decoding)
            # print(loss_encoding, loss_encoding1, loss_encoding2, loss_decoding1, loss_decoding)
            if optim is None:
                lr = None
            else:
                lr = np.log10(optim.param_groups[0]['lr'])

            ########
            if i == 0:
                output_attack_pad = output_attack[0:1]  # shape: (1, 3, 256, 256)
                if output_attack_pad.shape == (output_attack_pad.shape[0], 3, 256, 256):
                    output_attack_pad = torch.nn.functional.pad(output_attack_pad, (384, 384, 384, 384), mode='constant', value=0)# 使用 F.pad 进行零填充            # 格式: (左侧填充, 右侧填充, 顶部填充, 底部填充) 注意：从后往前填充维度
                # print(output_attack_pad.shape)  # 输出: torch.Size([1, 3, 1024, 1024])
                elif output_attack_pad.shape != (output.shape[0], 3, 1024, 1024):
                    output_attack_pad =torch.nn.functional.interpolate(output_attack_pad, size=(1024, 1024), mode='bilinear', align_corners=False)
            #################################################
            if mode == 'train':
                loss.backward()
                optim.step()
                if i == 0:
                    print(loss_encoding, loss_decoding)
                    image1 = torch.cat((watermark_map[0:1]*0.5+0.5, resize_inputs[0:1]*0.5+0.5, (encoded_output[0:1]*0.5+0.5).to(c.device), (decoded_watermark[0:1]*0.5+0.5).to(c.device)), dim=3)
                    torchvision.utils.save_image(image1,result_folder + f"train_results/step{step}/train_w_watt_in_out_dew.png")

                    image2 = torch.cat((inputs[0:1]*0.5+0.5, output[0:1]*0.5+0.5, output_attack_pad*0.5+0.5), dim=3)
                    torchvision.utils.save_image(image2, result_folder + f"train_results/step{step}/train_in_out_outatt_HW.png")

            elif mode == 'valid':
                torchvision.utils.save_image(inputs,result_folder + f"train_results/step{step}/original/{i}.png")
                torchvision.utils.save_image(output,result_folder + f"train_results/step{step}/watermarked/{i}.png")
                torchvision.utils.save_image(watermark_map,result_folder + f"train_results/step{step}/secret/{i}.png")
                torchvision.utils.save_image(decoded_watermark,result_folder + f"train_results/step{step}/secret-rev/{i}.png")
                if i == 0:
                    print(f"loss_encoding={loss_encoding}, loss_decoding={loss_decoding}")
                    image1 = torch.cat((watermark_map[0:1]*0.5+0.5, resize_inputs[0:1]*0.5+0.5, (encoded_output[0:1]*0.5+0.5).to(c.device), (decoded_watermark[0:1]*0.5+0.5).to(c.device)), dim=3)
                    torchvision.utils.save_image(image1,result_folder + f"train_results/step{step}/valid_w_watt_in_out_dew.png")

                    image2 = torch.cat((inputs[0:1]*0.5+0.5, output[0:1]*0.5+0.5, output_attack_pad*0.5+0.5), dim=3)
                    torchvision.utils.save_image(image2,result_folder + f"train_results/step{step}/valid_in_out_outatt_HW.png")
            elif mode == 'test' or mode == 'test_all':
                # print(ber)
                # print(loss_encoding, loss_encoding1, loss_encoding2, loss_decoding1, loss_decoding)
                torchvision.utils.save_image(inputs, result_folder + f"test_results/step{step}/original/{i}.png")
                torchvision.utils.save_image(output, result_folder + f"test_results/step{step}/watermarked/{i}.png")
                torchvision.utils.save_image(watermark_map, result_folder + f"test_results/step{step}/secret/{i}.png")
                torchvision.utils.save_image(decoded_watermark, result_folder + f"test_results/step{step}/secret-rev/{i}.png")
                if i==0:
                    image1 = torch.cat((watermark_map[0:1]*0.5+0.5, resize_inputs[0:1]*0.5+0.5, (encoded_output[0:1]*0.5+0.5).to(c.device), (decoded_watermark[0:1]*0.5+0.5).to(c.device)), dim=3)
                    torchvision.utils.save_image(image1, result_folder + f"train_results/step{step}/test_w_watt_in_out_dew.png")


                    image2 = torch.cat((inputs[0:1]*0.5+0.5, output[0:1]*0.5+0.5, output_attack_pad*0.5+0.5), dim=3)
                    torchvision.utils.save_image(image2, result_folder + f"train_results/step{step}/test_in_out_outatt_HW.png")
            total_loss.append(loss.item()) #+= loss.item()
            total_ber.append(ber)# += ber
            total_psnrc.append(psnrc)# +=psnrc
            total_psnrs.append(psnrs)# += psnrs
            total_ssimc.append(ssimc) #+= psnrs
            total_ssims.append(ssims) #+= psnrs
        avg_loss = sum(total_loss) / len(total_loss)
        avg_ber = sum(total_ber) / len(total_ber)
        avg_psnrc = sum(total_psnrc) / len(total_psnrc)
        avg_ssimc = sum(total_ssimc) / len(total_ssimc)
        avg_psnrs = sum(total_psnrs) / len(total_psnrs)
        avg_ssims = sum(total_ssims) / len(total_ssims)

        return lr, avg_loss, avg_ber, avg_psnrc, avg_ssimc, avg_psnrs, avg_ssims
# jpeg = JpegTest(50)
transform1 = transforms.Compose([
    transforms.Normalize([0.5, 0.5, 0.5], [0.5, 0.5, 0.5])
])


def main(main_mode, train_continue, project_name_continue, result_folder, step, strength, start_epoch, end_epoch, perceived_attack_layers=None, attack_layers=None, load_path = '', only_load_wtoi_itow=False):

    if step == 0:
        dataloader_train = range(int(len(train_dataloader)))
        dataloader_valid = range(int(len(valid_dataloader)))
        dataloader_test = range(int(len(test_dataloader)))
    else:
        dataloader_train = train_dataloader
        dataloader_valid = valid_dataloader
        dataloader_test = test_dataloader
    if main_mode == 'train':
        if step == 0:
            expinfo = f'wtoi_itow_pretrain'
            start_epoch = start_epoch
            end_epoch = end_epoch
        elif step == 1:
            expinfo = f'inn_wtoi_itow_pretrain'#f'inn_itow_pretrain'
            start_epoch = start_epoch
            end_epoch = end_epoch
        elif step == 2:
            expinfo = f'inn_wtoi_itow__finetune'
            start_epoch = start_epoch
            end_epoch = end_epoch
        if load_path != '':
            load_opt = c.load_opt#False
            if step == 1:
                if train_continue:
                    # load_path = f'{project_name_continue}/models/final_state/wtoi_itow_pretrain.pth'
                    load_path = f'{project_name_continue}/models/model_checkpoint_03000.pth'
                else:
                    load_path = f'{result_folder}/models/final_state/wtoi_itow_pretrain.pth'
            if step == 2:
                if train_continue:
                    # load_path = f'{project_name_continue}/models/final_state/inn_wtoi_itow_pretrain.pth'
                    load_path = f'{project_name_continue}/models/model_checkpoint_07500.pth'
                else:
                    load_path = f'{result_folder}/models/final_state/inn_wtoi_itow_pretrain.pth'

        else:
            load_opt = True

        net, optim, weight_scheduler = model_init(step=step, load_path=load_path, load_opt=load_opt, only_load_wtoi_itow=only_load_wtoi_itow)
        for i_epoch in range(start_epoch + 1, end_epoch + 1):
            lr, avg_loss, avg_ber, avg_psnrc, avg_ssimc, avg_psnrs, avg_ssims = run_model(result_folder, step, strength, dataloader_train, net, optim, perceived_attack_layers, attack_layers, i_epoch=i_epoch, epoch=end_epoch, mode='train')
            train_log_content = f"Epoch {i_epoch}/{end_epoch}, LR: {lr:.6f}, Loss: {avg_loss:.4f}, BER: {avg_ber:.4f}, PSNR_c: {avg_psnrc:.4f}, SSIM_c: {avg_ssimc:.4f}, PSNR_s: {avg_psnrs:.4f}, SSIM_s: {avg_ssims:.4f}\n"

            with open(result_folder + "/train_log.txt", "a") as file:
                file.write(train_log_content)
            if i_epoch % 50 == 0:
                with torch.no_grad():
                    lr, avg_loss, avg_ber, avg_psnrc, avg_ssimc, avg_psnrs, avg_ssims = run_model(result_folder, step, strength, dataloader_valid, net, optim, perceived_attack_layers, attack_layers, i_epoch=i_epoch, epoch=end_epoch, mode='valid')
                    val_log_content = f"Epoch {i_epoch}/{end_epoch}, LR: {lr:.6f}, Loss: {avg_loss:.4f}, BER: {avg_ber:.4f}, PSNR_c: {avg_psnrc:.4f}, SSIM_c: {avg_ssimc:.4f}, PSNR_s: {avg_psnrs:.4f}, SSIM_s: {avg_ssims:.4f}\n"
                    with open(result_folder + "/val_log.txt", "a") as file:
                        file.write(val_log_content)
                    print("Train", train_log_content)
                    print("Valid", val_log_content)
            if i_epoch > 0 and (i_epoch % 50) == 0:
                torch.save({'opt': optim.state_dict(), 'net': net.state_dict()}, result_folder + '/models/model_checkpoint_%.5i' % i_epoch + '.pth')
            weight_scheduler.step()

        torch.save({'opt': optim.state_dict(), 'net': net.state_dict()}, f'{result_folder}/models/final_state/{expinfo}.pth')


    elif main_mode == 'test_allmodels_allattacks':#test_epoch_log
        for i_epoch in range(start_epoch+1, end_epoch+1, 50):
            if i_epoch<10:
                load_path = f'{result_folder}/models/model_checkpoint_0000{i_epoch}.pth'
            elif 10<= i_epoch<100:
                load_path = f'{result_folder}/models/model_checkpoint_000{i_epoch}.pth'
            elif 100<=i_epoch < 1000:
                load_path = f'{result_folder}/models/model_checkpoint_00{i_epoch}.pth'
            elif 1000 <= i_epoch < 10000:
                load_path = f'{result_folder}/models/model_checkpoint_0{i_epoch}.pth'

            net, optim, weight_scheduler = model_init(step=step, load_path=load_path, load_opt = False, only_load_wtoi_itow=only_load_wtoi_itow)
            PSNR_all = []
            SSIM_all = []
            BER_all = []
            net.eval()
            attacks = [('Jpeg', JpegTest(50)), ('CP', C(0.03)), ('SP', SP(0.01)), ('HF', HF()), ('VF', VF()),
                       ('R', R()), ('P', P()), ('RC', RC()), ('RS', RS())]
            attack_ber_lists = {'Jpeg': [],'CP': [],'SP': [],'HF': [],'VF': [],'R': [],'P': [],'RC': [],'RS': []}# 为每种攻击创建一个存储BER的列表
            with torch.no_grad():
                start = time.time()
                for i, batch in enumerate(test_dataloader):
                    inputs = batch.to(c.device)
                    resize_inputs = transform(inputs)
                    secret = torch.Tensor(np.random.choice([0, 1], (inputs.shape[0], c.watermark_length))).to(c.device)
                    watermark_map = net.model_wtoi(secret)

                    forward_output = net.model_inn(torch.cat((dwt(resize_inputs), dwt(watermark_map)), 1))
                    output_z_guass = gauss_noise(forward_output.narrow(1, forward_output.shape[1] // 2, forward_output.shape[1] // 2).shape)
                    encoded_output = iwt(forward_output.narrow(1, 0, forward_output.shape[1] // 2))
                    orig_diff = transforms.Resize(inputs.shape[-2:])(encoded_output.to(c.device) - resize_inputs)
                    controlled_diff = orig_diff * strength
                    output = torch.clamp(inputs + controlled_diff, min=-1.0, max=1.0)
                    psnr = kornia.losses.psnr_loss(output.detach().to(c.device), inputs.to(c.device), 2).item()
                    ssim = 1 - 2 * kornia.losses.ssim_loss(output.detach().to(c.device), inputs.to(c.device), window_size=5, reduction="mean").item()
                    # psnr = image_psnr((output).detach().cpu(), (inputs).cpu())
                    # ssim = image_ssim((output).detach().cpu(), (inputs).cpu())
                    PSNR_all.append(psnr)
                    SSIM_all.append(ssim)

                    for attack_name, attack in attacks:
                        output_attack = attack([output, inputs])

                        trans_images = transform(output_attack)
                        trans_images = dwt(trans_images)

                        backward_output = net.model_inn(torch.cat((trans_images, output_z_guass.to(c.device)), 1), rev=True)
                        decoded_watermark = iwt(backward_output.narrow(1, backward_output.shape[1] // 2, backward_output.shape[1] // 2))
                        decoded_secret = net.model_itow(decoded_watermark.to(c.device))
                        ber = decoded_message_error_rate_batch(decoded_secret, secret)
                        # BER_all.append(ber)
                        attack_ber_lists[attack_name].append(ber)                        # 存储到对应的列表
                        # BER_all.append(ber)  # 原有的总BER列表
                end = time.time()
                avg_psnr = sum(PSNR_all) / len(PSNR_all)
                avg_ssim = sum(SSIM_all) / len(SSIM_all)
                attack_avg_ber = {}# 计算每种攻击的平均BER

                print(f"各种攻击的平均PSNRSSIM结果：PSNR:{avg_psnr}, SSIM:{avg_ssim}")
                for attack_name, ber_list in attack_ber_lists.items():
                    if ber_list:  # 确保列表不为空
                        avg_ber = sum(ber_list) / len(ber_list)
                        attack_avg_ber[attack_name] = avg_ber
                        # print(f"{attack_name}: {avg_ber:.6f}")
                    else:
                        print(f"{attack_name}: 无数据")
                print(f"各种攻击的平均BER结果：{attack_avg_ber}")
                test_log_content = f"Epoch {i_epoch}/{end_epoch}, PSNR: {avg_psnr:.4f}, SSIM: {avg_ssim:.4f}, " \
                                   f"Jpeg: {attack_avg_ber['Jpeg']:.4f}, CP: {attack_avg_ber['CP']:.4f}, SP: {attack_avg_ber['SP']:.4f}" \
                                   f"HF: {attack_avg_ber['HF']:.4f}, VF: {attack_avg_ber['VF']:.4f}, " \
                                   f"R: {attack_avg_ber['R']:.4f}, P: {attack_avg_ber['P']:.4f}," \
                                   f"RC: {attack_avg_ber['RC']:.4f}, RS: {attack_avg_ber['RS']:.4f},\n"
                with open(result_folder + "/test_allattacks_allmodels_log.txt", "a") as file:
                    file.write(test_log_content)
                test_log_content1 = f"---------------------------------------------------,\n"
                with open(result_folder + "/test_allattacks_allmodels_log.txt", "a") as file:
                    file.write(test_log_content1)
                # print('T', end-start)
                # print("-" * 40)

    elif main_mode == 'test_allmodels_basicattacks':#test_epoch_log
        for i_epoch in range(start_epoch+1, end_epoch+1, 50):
            if i_epoch<10:
                load_path = f'{result_folder}/models/model_checkpoint_0000{i_epoch}.pth'
            elif 10<= i_epoch<100:
                load_path = f'{result_folder}/models/model_checkpoint_000{i_epoch}.pth'
            elif 100<=i_epoch < 1000:
                load_path = f'{result_folder}/models/model_checkpoint_00{i_epoch}.pth'
            elif 1000 <= i_epoch < 10000:
                load_path = f'{result_folder}/models/model_checkpoint_0{i_epoch}.pth'

            net, optim, weight_scheduler = model_init(step=step, load_path=load_path, load_opt = False, only_load_wtoi_itow=only_load_wtoi_itow)
            PSNR_all = []
            SSIM_all = []
            BER_all = []
            net.eval()
            # attacks = [('Jpeg', JpegTest(50)), ('CP', C(0.0625))]
            # attack_ber_lists = {'Jpeg': [],'CP': []}# 为每种攻击创建一个存储BER的列表
            attacks = [('CP', C(0.0625))]
            attack_ber_lists = {'CP': []}  # 为每种攻击创建一个存储BER的列表
            with torch.no_grad():
                start = time.time()
                for i, batch in enumerate(test_dataloader):
                    if i ==0:
                        aaaaa=batch.to(c.device)
                    inputs = batch.to(c.device)
                    resize_inputs = transform(inputs)
                    secret = torch.Tensor(np.random.choice([0, 1], (inputs.shape[0], c.watermark_length))).to(c.device)
                    watermark_map = net.model_wtoi(secret)

                    forward_output = net.model_inn(torch.cat((dwt(resize_inputs), dwt(watermark_map)), 1))
                    output_z_guass = gauss_noise(forward_output.narrow(1, forward_output.shape[1] // 2, forward_output.shape[1] // 2).shape)
                    encoded_output = iwt(forward_output.narrow(1, 0, forward_output.shape[1] // 2))
                    orig_diff = transforms.Resize(inputs.shape[-2:])(encoded_output.to(c.device) - resize_inputs)
                    controlled_diff = orig_diff * strength
                    output = torch.clamp(inputs + controlled_diff, min=-1.0, max=1.0)
                    psnr = kornia.losses.psnr_loss(output.detach().to(c.device), inputs.to(c.device), 2).item()
                    ssim = 1 - 2 * kornia.losses.ssim_loss(output.detach().to(c.device), inputs.to(c.device), window_size=5, reduction="mean").item()
                    # psnr = image_psnr((output).detach().cpu(), (inputs).cpu())
                    # ssim = image_ssim((output).detach().cpu(), (inputs).cpu())
                    PSNR_all.append(psnr)
                    SSIM_all.append(ssim)

                    for attack_name, attack in attacks:
                        output_attack = attack([output, inputs])
                        trans_images = transform(output_attack)
                        trans_images = dwt(trans_images)

                        backward_output = net.model_inn(torch.cat((trans_images, output_z_guass.to(c.device)), 1), rev=True)
                        decoded_watermark = iwt(backward_output.narrow(1, backward_output.shape[1] // 2, backward_output.shape[1] // 2))
                        decoded_secret = net.model_itow(decoded_watermark.to(c.device))
                        ber = decoded_message_error_rate_batch(decoded_secret, secret)
                        # BER_all.append(ber)
                        attack_ber_lists[attack_name].append(ber)                        # 存储到对应的列表
                        # BER_all.append(ber)  # 原有的总BER列表
                end = time.time()
                avg_psnr = sum(PSNR_all) / len(PSNR_all)
                avg_ssim = sum(SSIM_all) / len(SSIM_all)
                attack_avg_ber = {}# 计算每种攻击的平均BER

                print(f"各种攻击的平均PSNRSSIM结果：PSNR:{avg_psnr}, SSIM:{avg_ssim}")
                for attack_name, ber_list in attack_ber_lists.items():
                    if ber_list:  # 确保列表不为空
                        avg_ber = sum(ber_list) / len(ber_list)
                        attack_avg_ber[attack_name] = avg_ber
                        # print(f"{attack_name}: {avg_ber:.6f}")
                    else:
                        print(f"{attack_name}: 无数据")
                print(f"各种攻击的平均BER结果：{attack_avg_ber}")
                test_log_content = f"Epoch {i_epoch}/{end_epoch}, PSNR: {avg_psnr:.4f}, SSIM: {avg_ssim:.4f}, " \
                                   f"Jpeg: {attack_avg_ber['Jpeg']:.4f}, CP: {attack_avg_ber['CP']:.4f} \n"
                with open(result_folder + "/test_basicattacks_allmodels_log.txt", "a") as file:
                    file.write(test_log_content)
                test_log_content1 = f"---------------------------------------------------,\n"
                with open(result_folder + "/test_basicattacks_allmodels_log.txt", "a") as file:
                    file.write(test_log_content1)
                # print('T', end-start)
                # print("-" * 40)




def load(step, net, optim, name, load_opt=True):    # print('load net and optim', step)
    state_dicts = torch.load(name, map_location=c.device)
    network_state_dict = {k: v for k, v in state_dicts['net'].items() if 'tmp_var' not in k}
    net.load_state_dict(network_state_dict)
    if load_opt == True:
        optim.load_state_dict(state_dicts['opt'])
    # print(f'Step{step}: load path({name}) -----------------------------------OK')
    print(f'Step{step}: load path{name[-30:]} ------OK')
    return net, optim

def load_wtoi_itow_from_pretrained(net, pretrained_path):
    """从完整的预训练模型中只加载Watermark2Image和Image2Watermark模块"""
    print(f"Loading Watermark2Image and Image2Watermark from: {pretrained_path}")

    # 加载预训练模型的完整state_dict
    checkpoint = torch.load(pretrained_path, map_location=c.device)
    pretrained_dict = checkpoint['net']

    # 获取当前模型的state_dict
    model_dict = net.state_dict()

    # 筛选出wtoi和itow的参数（跳过INN相关参数）
    loaded_params = {}
    for k, v in pretrained_dict.items():
        if 'wtoi' in k or 'itow' in k:
            if k in model_dict:
                if model_dict[k].shape == v.shape:
                    model_dict[k] = v
                    loaded_params[k] = v
                    print(f"✓ Loaded: {k}")
                else:
                    print(f"✗ Shape mismatch: {k} (expected {model_dict[k].shape}, got {v.shape})")
            else:
                print(f"✗ Not found in current model: {k}")
        else:
            print(f"- Skipped (INN or other): {k}")

    # 加载更新后的state_dict
    net.load_state_dict(model_dict)

    print(f"Successfully loaded {len(loaded_params)} parameters from Watermark2Image and Image2Watermark")
    return net
def get_parameter_number(net):
    total_num = sum(p.numel() for p in net.parameters())
    trainable_num = sum(p.numel() for p in net.parameters() if p.requires_grad)
    return {'Total': total_num, 'Trainable': trainable_num}
def model_init(step, load_path='',load_opt=True, only_load_wtoi_itow=False):
    net = Models(Norm=c.Norm, MLP_smooth=c.MLP_smooth, watermark_length=c.watermark_length, diffusion_length=c.diffusion_length, num_blocks=c.num_blocks, harr=harr, bias=bias, FMDB_channel=c.FMDB_channel)
    if step == 0:
        lr = c.lr0
        step_size = c.step_size0
        gamma = c.gamma0
        for name, para in net.named_parameters():
            if 'inn' in name:
                para.requires_grad = False
            elif 'itow' in name:
                para.requires_grad = True
            elif 'wtoi' in name:
                para.requires_grad = True

    elif step == 1:
        lr = c.lr1
        step_size = c.step_size1
        gamma = c.gamma1
        for name, para in net.named_parameters():
            if 'inn' in name:
                para.requires_grad = True
            elif 'itow' in name:
                para.requires_grad = True
            elif 'wtoi' in name:
                para.requires_grad = True

    elif step == 2:
        lr = c.lr2
        step_size = c.step_size2
        gamma = c.gamma2
        for name, para in net.named_parameters():
            if 'inn' in name:
                para.requires_grad = True
            elif 'wtoi' in name:
                para.requires_grad = True
            elif 'itow' in name:
                para.requires_grad = True
    net.to(c.device)
    init_model(net)
    # net = nn.DataParallel(net, device_ids=c.device_ids)

    # para = get_parameter_number(net)
    # print(para)
    optim = torch.optim.Adam(list(filter(lambda x: x.requires_grad, net.parameters())), lr=lr, betas=(0.5, 0.999), eps=1e-6, weight_decay=1e-5)
    weight_scheduler = torch.optim.lr_scheduler.StepLR(optim, step_size, gamma)

    if load_path != '':
        if only_load_wtoi_itow:
            net = load_wtoi_itow_from_pretrained(net, load_path)
        else:
            net, optim = load(step, net, optim, load_path, load_opt)
    # print(f"weight dtype:{next(net.parameters()).dtype}")
    # print(f"weight device:{next(net.parameters()).device}")

    return net, optim, weight_scheduler

def gauss_noise(shape):
    noise = torch.zeros(shape).cuda()
    for i in range(noise.shape[0]):
        noise[i] = torch.randn(noise[i].shape).cuda()
    return noise

def computePSNR(origin,pred):
    mse = torch.mean((origin/1.0 - pred/1.0) ** 2 )
    if mse < 1.0e-10:
      return 100
    return 10 * torch.log10(1.0/mse).item()
def decoded_message_error_rate(message, decoded_message):
    """计算单个消息的误码率"""
    length = message.shape[0]
    message = message.gt(0.5)
    decoded_message = decoded_message.gt(0.5)
    error_rate = float(sum(message != decoded_message)) / length
    return error_rate
def decoded_message_error_rate_batch(messages, decoded_messages):
    """计算批处理的误码率"""
    error_rate = 0.0
    batch_size = len(messages)
    for i in range(batch_size):
        error_rate += decoded_message_error_rate(messages[i], decoded_messages[i])
    error_rate /= batch_size
    return error_rate
def image_psnr(preds, targets, data_range=2.0):
    psnr = PeakSignalNoiseRatio(data_range=data_range)
    return psnr(preds, targets)
def image_ssim(preds, targets, data_range=2.0):
    ssim = StructuralSimilarityIndexMeasure(data_range=data_range)
    return ssim(preds, targets)