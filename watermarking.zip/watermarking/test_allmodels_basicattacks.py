import torch
from network.Noise import Noise


from main import main
if __name__ == "__main__":
    torch.backends.cudnn.benchmark = True
    torch.backends.cudnn.deterministic = False
    main_mode = 'test_allmodels_basicattacks'
    # def set_seed(seed):
    #     random.seed(seed)
    #     np.random.seed(seed)
    #     torch.manual_seed(seed)
    #     torch.cuda.manual_seed(seed)
    #     torch.cuda.manual_seed_all(seed)  # 如果你有多张卡
    # set_seed(42)  # 在2080和A800上都用同一个种子运行
    if main_mode == 'test_allmodels_basicattacks':
        from utils.load_test_setting import *
        result_folder_attack = attack_layers.copy()
        perceived_attack_layers = Noise(perceived_attack_layers)
        attack_layers = Noise(attack_layers)

        main(main_mode, train_continue, project_name_continue, result_folder, 1, 0.6, 5899, 5900, perceived_attack_layers, attack_layers, '', only_load_wtoi_itow)
