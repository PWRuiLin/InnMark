import random


def get_random_float(float_range: [float]):
	return random.random() * (float_range[1] - float_range[0]) + float_range[0]


def get_random_int(int_range: [int]):
	return random.randint(int_range[0], int_range[1])


from .all import Identity
# from .crop import Crop
from .all import Crop as C1
from .all import Crop1 as C

from .all import HorizontalFlip1 as HF1
from .all import VerticalFlip1 as VF1
from .all import Rotation1 as R1
from .all import Perspective1 as P1
from .all import ResizedCrop1 as RC1
from .all import ResizedCrop2 as RC2
from .all import JpegTest

from .all import SaltAndPepperNoise as SP
from .all import HorizontalFlip as HF
from .all import VerticalFlip as VF
from .all import Rotation as R
from .all import Perspective as P
from .all import ResizedCrop as RC
from .all import Resize1 as RS
from .combined import Combined

from .all import Arbitrary_Resolution as AR