# import v2
from kornia import augmentation as aug
import os
import torch
import torch.nn as nn
import numpy as np
from torchvision import transforms
from PIL import Image
import random, string
Image.MAX_IMAGE_PIXELS = None

class HorizontalFlip1(nn.Module):
    def __init__(self, p=1.0):
        super(HorizontalFlip1, self).__init__()
        self.attack = aug.RandomHorizontalFlip(p=p)
    def forward(self, image_and_cover):
        image, cover = image_and_cover
        image = image * 0.5 + 0.5
        image = self.attack(image)
        image = (image - 0.5) * 2
        return image

class VerticalFlip1(nn.Module):
    def __init__(self, p=1.0):
        super(VerticalFlip1, self).__init__()
        self.attack = aug.RandomVerticalFlip(p=p)
    def forward(self, image_and_cover):
        image, cover = image_and_cover
        image = image * 0.5 + 0.5
        image = self.attack(image)
        image = (image - 0.5) * 2
        return image

class Rotation1(nn.Module):
    def __init__(self, degrees=5.0, p=1.0):
        super(Rotation1, self).__init__()
        self.attack = aug.RandomRotation(degrees=degrees, p=p)
    def forward(self, image_and_cover):
        image, cover = image_and_cover
        image = image * 0.5 + 0.5
        image = self.attack(image)
        image = (image - 0.5) * 2
        return image

class Perspective1(nn.Module):
    def __init__(self, distortion_scale=0.05, p=1.0):
        super(Perspective1, self).__init__()
        self.attack = aug.RandomPerspective(distortion_scale=distortion_scale, p=p)
    def forward(self, image_and_cover):
        image, cover = image_and_cover
        image = image * 0.5 + 0.5
        image = self.attack(image)
        image = (image - 0.5) * 2
        return image

class Resize1(nn.Module):
    def __init__(self, size=(512,512)):
        super(Resize1, self).__init__()
        self.attack = aug.Resize(size=size)
    def forward(self, image_and_cover):
        image, cover = image_and_cover
        image = image * 0.5 + 0.5
        image = self.attack(image)
        image = (image - 0.5) * 2
        return image

class ResizedCrop1(nn.Module):
    def __init__(self, size=(512,512), scale=(0.8,0.8), ratio=(1.0,1.0)):
        super(ResizedCrop1, self).__init__()
        self.attack = aug.RandomResizedCrop(size=size, scale=scale, ratio=ratio)
    def forward(self, image_and_cover):
        image, cover = image_and_cover
        image = image * 0.5 + 0.5
        image = self.attack(image)
        image = (image - 0.5) * 2
        return image

class ResizedCrop2(nn.Module):
    def __init__(self, size=(128,128), scale=(0.8,0.8), ratio=(1.0,1.0)):
        super(ResizedCrop2, self).__init__()
        self.attack = aug.RandomResizedCrop(size=size, scale=scale, ratio=ratio)
    def forward(self, image_and_cover):
        image, cover = image_and_cover
        image = image * 0.5 + 0.5
        image = self.attack(image)
        image = (image - 0.5) * 2
        return image

##############################################YIXIA CESHI

class HorizontalFlip(nn.Module):
    def __init__(self, p=1.0):
        super(HorizontalFlip, self).__init__()
        self.attack = aug.RandomHorizontalFlip(p=p)
    def forward(self, image_and_cover):
        image, cover = image_and_cover
        image = image * 0.5 + 0.5
        image = self.attack(image)
        image = (image - 0.5) * 2
        return image

class VerticalFlip(nn.Module):
    def __init__(self, p=1.0):
        super(VerticalFlip, self).__init__()
        self.attack = aug.RandomVerticalFlip(p=p)
    def forward(self, image_and_cover):
        image, cover = image_and_cover
        image = image * 0.5 + 0.5
        image = self.attack(image)
        image = (image - 0.5) * 2
        return image

class Rotation(nn.Module):
    def __init__(self, degrees, p=1.0):
        super(Rotation, self).__init__()
        self.attack = aug.RandomRotation(degrees=degrees, p=p)
    def forward(self, image_and_cover):
        image, cover = image_and_cover
        image = image * 0.5 + 0.5
        image = self.attack(image)
        image = (image - 0.5) * 2
        return image

class Perspective(nn.Module):
    def __init__(self, distortion_scale, p=1.0):
        super(Perspective, self).__init__()
        self.attack = aug.RandomPerspective(distortion_scale=distortion_scale, p=p)
    def forward(self, image_and_cover):
        image, cover = image_and_cover
        image = image * 0.5 + 0.5
        image = self.attack(image)
        image = (image - 0.5) * 2
        return image


class Resize(nn.Module):
    def __init__(self, size):
        super(Resize, self).__init__()
        self.attack = aug.Resize(size=size)
    def forward(self, image_and_cover):
        image, cover = image_and_cover
        image = image * 0.5 + 0.5
        image = self.attack(image)
        image = (image - 0.5) * 2
        return image

class ResizedCrop(nn.Module):
    def __init__(self, size, scale, ratio):
        super(ResizedCrop, self).__init__()
        self.attack = aug.RandomResizedCrop(size=size, scale=scale, ratio=ratio)
    def forward(self, image_and_cover):
        image, cover = image_and_cover
        image = image * 0.5 + 0.5
        image = self.attack(image)
        image = (image - 0.5) * 2
        return image

class Erasing(nn.Module):
    def __init__(self, scale, ratio, p=1.0):
        super(Erasing, self).__init__()
        self.attack = aug.RandomErasing(scale=scale, ratio=ratio, p=p)
    def forward(self, image_and_cover):
        image, cover = image_and_cover
        image = image * 0.5 + 0.5
        image = self.attack(image)
        image = (image - 0.5) * 2
        return image

class Brightness(nn.Module):
    def __init__(self, brightness):
        super(Brightness, self).__init__()
        self.attack = aug.RandomBrightness(brightness=brightness)
    def forward(self, image_and_cover):
        image, cover = image_and_cover
        image = image * 0.5 + 0.5
        image = self.attack(image)
        image = (image - 0.5) * 2
        return image
class Darker(nn.Module):
    def __init__(self, brightness):
        super(Darker, self).__init__()
        self.attack = aug.RandomBrightness(brightness=brightness)
    def forward(self, image_and_cover):
        image, cover = image_and_cover
        image = image * 0.5 + 0.5
        image = self.attack(image)
        image = (image - 0.5) * 2
        return image

class Contrast(nn.Module):
    def __init__(self, contrast):
        super(Contrast, self).__init__()
        self.attack = aug.RandomContrast(contrast=contrast)
    def forward(self, image_and_cover):
        image, cover = image_and_cover
        image = image * 0.5 + 0.5
        image = self.attack(image)
        image = (image - 0.5) * 2
        return image
class Saturation(nn.Module):
    def __init__(self, saturation):
        super(Saturation, self).__init__()
        self.attack = aug.RandomSaturation(saturation=saturation)
    def forward(self, image_and_cover):
        image, cover = image_and_cover
        image = image * 0.5 + 0.5
        image = self.attack(image)
        image = (image - 0.5) * 2
        return image

class ColorJiggle(nn.Module):
    def __init__(self, brightness, contrast, saturation, hue):
        super(ColorJiggle, self).__init__()
        self.attack = aug.ColorJiggle(brightness=brightness, contrast=contrast, saturation=saturation, hue=hue)
    def forward(self, image_and_cover):
        image, cover = image_and_cover
        image = image * 0.5 + 0.5
        image = self.attack(image)
        image = (image - 0.5) * 2
        return image
class Posterize(nn.Module):
    def __init__(self, bits, p=1.0):
        super(Posterize, self).__init__()
        self.attack = aug.RandomPosterize(bits=bits, p=p)
    def forward(self, image_and_cover):
        image, cover = image_and_cover
        image = image * 0.5 + 0.5
        image = self.attack(image)
        image = (image - 0.5) * 2
        return image
class RGBShift(nn.Module):
    def __init__(self, r_shift_limit, g_shift_limit, b_shift_limit, p=1.0):
        super(RGBShift, self).__init__()
        self.attack = aug.RandomRGBShift(r_shift_limit=r_shift_limit, g_shift_limit=g_shift_limit, b_shift_limit=b_shift_limit, p=p)
    def forward(self, image_and_cover):
        image, cover = image_and_cover
        image = image * 0.5 + 0.5
        image = self.attack(image)
        image = (image - 0.5) * 2
        return image



class BoxBlur(nn.Module):
    def __init__(self, kernel_size, p=1):
        super(BoxBlur, self).__init__()
        self.attack = aug.RandomBoxBlur(kernel_size=kernel_size, p=p)
    def forward(self, image_and_cover):
        image, cover = image_and_cover
        image = image * 0.5 + 0.5
        image = self.attack(image)
        image = (image - 0.5) * 2
        return image
class GaussianBlur(nn.Module):
    def __init__(self, kernel_size, sigma, p=1.0):
        super(GaussianBlur, self).__init__()
        self.attack = aug.RandomGaussianBlur(kernel_size=kernel_size, sigma=sigma, p=p)
    def forward(self, image_and_cover):
        image, cover = image_and_cover
        image = image * 0.5 + 0.5
        image = self.attack(image)
        image = (image - 0.5) * 2
        return image
class GaussianNoise(nn.Module):
    def __init__(self, mean, std, p=1.0):
        super(GaussianNoise, self).__init__()
        self.attack = aug.RandomGaussianNoise(mean=mean, std=std, p=p)
    def forward(self, image_and_cover):
        image, cover = image_and_cover
        image = image * 0.5 + 0.5
        image = self.attack(image)
        image = (image - 0.5) * 2
        return image


class SaltAndPepperNoise(nn.Module):
    def __init__(self, amount, salt_vs_pepper=(0.5, 0.5), p=1):
        super(SaltAndPepperNoise, self).__init__()
        self.attack = aug.RandomSaltAndPepperNoise(amount=amount, salt_vs_pepper = salt_vs_pepper, p=p)
    def forward(self, image_and_cover):
        image, cover = image_and_cover
        image = image * 0.5 + 0.5
        image = self.attack(image)
        image = (image - 0.5) * 2
        return image

class MedianBlur(nn.Module):
    def __init__(self, kernel_size, p=1.0):
        super(MedianBlur, self).__init__()
        self.attack = aug.RandomMedianBlur(kernel_size=kernel_size, p=p)
    def forward(self, image_and_cover):
        image, cover = image_and_cover
        image = image * 0.5 + 0.5
        image = self.attack(image)
        image = (image - 0.5) * 2
        return image
############################
def random_float(min, max):
    """
    Return a random number
    :param min:
    :param max:
    :return:
    """
    return np.random.rand() * (max - min) + min
def get_random_rectangle_inside(image, height_ratio_range, width_ratio_range):

    image_height = image.shape[2]
    image_width = image.shape[3]

    remaining_height = int(np.rint(random_float(height_ratio_range, height_ratio_range) * image_height))
    remaining_width = int(np.rint(random_float(width_ratio_range, width_ratio_range) * image_width))

    if remaining_height == image_height:
        height_start = 0
    else:#np.random.randint()返回一个随机整数，包括低范围，不包括高范围
        height_start = np.random.randint(0, image_height - remaining_height)

    if remaining_width == image_width:
        width_start = 0
    else:
        width_start = np.random.randint(0, image_width - remaining_width)

    return height_start, height_start+remaining_height, width_start, width_start+remaining_width
class Crop(nn.Module):
    def __init__(self, ratio):
        super(Crop, self).__init__()
        self.height_ratio = np.sqrt(ratio)#height_ratio
        self.width_ratio = np.sqrt(ratio)#width_ratio
    def forward(self, image_and_cover):
        image, cover_image = image_and_cover
        image = image * 0.5 +0.5
        h_start, h_end, w_start, w_end = get_random_rectangle_inside(image, self.height_ratio, self.width_ratio)
        cropped_image = image[:, :, h_start:h_end, w_start:w_end]
        cropped_image = (cropped_image - 0.5) * 2
        return cropped_image#image * mask

class Crop1(nn.Module):
    def __init__(self, ratio):
        super(Crop1, self).__init__()
        self.height_ratio = np.sqrt(ratio)  # height_ratio
        self.width_ratio = np.sqrt(ratio)  # width_ratio
    def forward(self, image_and_cover):
        image, cover_image = image_and_cover
        image = image * 0.5 + 0.5
        h_start, h_end, w_start, w_end = get_random_rectangle_inside(image, self.height_ratio, self.width_ratio)
        mask = torch.zeros_like(image)
        mask[:, :, h_start: h_end, w_start: w_end] = 1
        output = image * mask
        output = (output - 0.5) * 2
        return output

class JpegTest(nn.Module):
	def __init__(self, Q, subsample=2, path="temp/"):
		super(JpegTest, self).__init__()
		self.Q = Q
		self.subsample = subsample
		self.path = path
		if not os.path.exists(path): os.mkdir(path) #如果指定的保存路径不存在，则创建该路径。

	def get_path(self):
		return self.path + ''.join(random.sample(string.ascii_letters + string.digits, 16)) + ".jpg" #在临时路径后面拼接16位随机字母和数字组成的文件名，并加上".jpg"后缀，返回生成的临时文件路径。

	def forward(self, image_and_cover):
		image, cover_image = image_and_cover

		shape = image.shape
		noised_image = torch.zeros_like(image)#创建一个与原始图像形状相同的全零张量，用于存储压缩后的图像。

		for i in range(shape[0]): #遍历原始图像的所有通道。
			single_image = ((image[i].clamp(-1, 1).permute(1, 2, 0) + 1) / 2 * 255).to('cpu', torch.uint8).numpy() #将当前通道的原始图像张量转换为NumPy数组，并将像素值归一化到0-255范围内。
			im = Image.fromarray(single_image) #使用PIL库将NumPy数组转换为PIL图像对象。

			file = self.get_path()#调用get_path()方法获取临时文件路径。
			while os.path.exists(file): #如果生成的临时文件路径已经存在，则重新生成，直到得到一个不存在的临时文件路径。
				file = self.get_path()
			im.save(file, format="JPEG", quality=self.Q, subsampling=self.subsample) #将PIL图像对象以JPEG格式保存到临时文件中，指定压缩质量因子为self.Q，子采样级别为self.subsample。
			jpeg = np.array(Image.open(file), dtype=np.uint8)#使用PIL库打开保存的JPEG压缩图像文件，并将其转换为NumPy数组。
			os.remove(file)#删除临时文件。

			transform = transforms.Compose([
				transforms.ToTensor(),
				transforms.Normalize([0.5, 0.5, 0.5], [0.5, 0.5, 0.5])
			])#定义了一个图像转换管道，将NumPy数组转换为PyTorch张量，并进行归一化处理。

			noised_image[i] = transform(jpeg).unsqueeze(0).to(image.device)#将处理后的图像张量赋值给noised_image张量的当前通道。

		return noised_image



def get_random_augmentation(aug_type):
    direction = random.choice(['increase', 'decrease'])
    if aug_type == 'Brightness':
        if direction == 'increase':
            return Brightness(brightness=(1.25, 1.25))
        else:
            return Brightness(brightness=(0.75, 0.75))
    elif aug_type == 'Contrast':
        if direction == 'increase':
            return Contrast(contrast=(1.25, 1.25))
        else:
            return Contrast(contrast=(0.75, 0.75))
    elif aug_type == 'Saturation':
        if direction == 'increase':
            return Saturation(saturation=(1.25, 1.25))
        else:
            return Saturation(saturation=(0.75, 0.75))
    elif aug_type == 'Flip':
        if direction == 'increase':
            return HorizontalFlip()
        else:
            return VerticalFlip()



class Identity(nn.Module):
	"""
	Identity-mapping noise layer. Does not change the image
	"""

	def __init__(self):
		super(Identity, self).__init__()

	def forward(self, image_and_cover):
		image, cover_image = image_and_cover
		return image

class Sharpness(nn.Module):
    def __init__(self, sharpness_range=(0.0, 1.0), p=1):
        super(Sharpness, self).__init__()
        self.attack = aug.RandomSharpness(sharpness=sharpness_range, p=p)
    def forward(self, image_and_cover):
        image, cover = image_and_cover
        image = image * 0.5 + 0.5
        image = self.attack(image)
        image = (image - 0.5) * 2
        return image


class Arbitrary_Resolution(nn.Module):
    def __init__(self, H=256, W=256):
        super(Arbitrary_Resolution, self).__init__()
        self.attack = transforms.Compose([transforms.Resize((H, W))])

    def forward(self, image_and_cover):
        image, cover = image_and_cover
        image = self.attack(image)
        return image

#MedianBlur SP


# Medium level noise
# def supported_transforms(image_size):
#     return {
#     'HFlip': aug.RandomHorizontalFlip(p=1.0),
#     'VFlip': aug.RandomVerticalFlip(p=1.0),
#     "Rotation":  aug.RandomRotation(degrees=[0.0, 10.0], p=1.0),
#     'Perspective': aug.RandomPerspective(distortion_scale=0.1, p=1.0),
#     'RandomResizedCrop':  aug.RandomResizedCrop(size=image_size, scale=(0.75, 1.0), ratio=(3.0 / 4.0, 4.0 / 3.0)),
#     'Brighter':  aug.RandomBrightness(brightness=(1.25, 1.25)), # 0.5-1.5
#     'Darker':  aug.RandomBrightness(brightness=(0.75, 0.75)), # 0.5-1.5
#     'Contrast_p': aug.RandomContrast(contrast=(1.25, 1.25)), # 0.5 - 1.5
#     'Contrast_m': aug.RandomContrast(contrast=(0.75, 0.75)), # 0.5 - 1.5
#     'Saturation_p': aug.RandomSaturation(saturation=(1.25, 1.25)), #
#     'Saturation_m': aug.RandomSaturation(saturation=(0.75, 0.75)), #
#     'BoxBlur': aug.RandomBoxBlur(kernel_size=(5, 5), p= 1.0), # 7.
#     'GaussianBlur': aug.RandomGaussianBlur(kernel_size=(5, 5), sigma=(1.0, 1.5), p=1.0), # 7, 0.1-2.0
#     'GaussianNoise': aug.RandomGaussianNoise(mean=0.0, std=0.04, p=1.0), # 0.08
#     "Jpeg": v2.JPEG(quality=[50, 50]), # it is expected to have dtype uint8, on CPU, and have [..., 3 or 1, H, W] shape 40
#     'RandomErasing': aug.RandomErasing(scale=(0.02, 0.1), ratio=(0.5, 1.5), p=1.0),
#     "Jiggle":  aug.ColorJiggle(brightness=0.1, contrast=0.1, saturation=0.1, hue=0.02),
#     "Posterize": aug.RandomPosterize(bits=4),
#     "RGBShift": aug.RandomRGBShift(r_shift_limit=0.05, g_shift_limit=0.05, b_shift_limit=0.05, p=1.0),
#     }