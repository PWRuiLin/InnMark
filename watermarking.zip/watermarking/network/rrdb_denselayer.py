import torch
import torch.nn as nn
import network.module_util as mutil
import torch.nn.functional as F
# Dense connection
class ResidualDenseBlock_out(nn.Module):
    def __init__(self, input, output, bias=True):
        super(ResidualDenseBlock_out, self).__init__()
        self.conv1 = nn.Conv2d(input, 32, 3, 1, 1, bias=bias)
        self.conv2 = nn.Conv2d(input + 32, 32, 3, 1, 1, bias=bias)
        self.conv3 = nn.Conv2d(input + 2 * 32, 32, 3, 1, 1, bias=bias)
        self.conv4 = nn.Conv2d(input + 3 * 32, 32, 3, 1, 1, bias=bias)
        self.conv5 = nn.Conv2d(input + 4 * 32, output, 3, 1, 1, bias=bias)
        self.lrelu = nn.LeakyReLU(inplace=True)
        # initialization
        mutil.initialize_weights([self.conv5], 0.)

    def forward(self, x):
        x1 = self.lrelu(self.conv1(x))
        x2 = self.lrelu(self.conv2(torch.cat((x, x1), 1)))
        x3 = self.lrelu(self.conv3(torch.cat((x, x1, x2), 1)))
        x4 = self.lrelu(self.conv4(torch.cat((x, x1, x2, x3), 1)))
        x5 = self.conv5(torch.cat((x, x1, x2, x3, x4), 1))
        return x5




class SAFM(nn.Module):
    def __init__(self, dim, DWT=True,  bias=True): # NoDWT:1      YesDWT:4
        super().__init__()
        n_levels=4
        #     n_levels=1
        self.n_levels = n_levels
        chunk_dim = dim // n_levels

        self.conv1 = nn.Conv2d(chunk_dim, chunk_dim, 3, 1, 1, bias=bias)
        self.conv2 = nn.Conv2d(chunk_dim * 2, chunk_dim, 3, 1, 1, bias=bias)
        # Feature Aggregation
        self.aggr = nn.Conv2d(dim, dim, 1, 1, 0, bias=bias)

        # Activation
        self.lrelu = nn.LeakyReLU(inplace=True)

    def forward(self, x):
        h, w = x.size()[-2:]

        xc = x.chunk(self.n_levels, dim=1)
        out = []
        for i in range(self.n_levels):
            if i > 0:
                p_size = (h // 2 ** i, w // 2 ** i)
                s = F.adaptive_max_pool2d(xc[i], p_size)
                s1 = self.conv1(s)
                s2 = self.conv2(torch.cat((s, s1), dim=1))
                s_out = F.interpolate(s2, size=(h, w), mode='nearest')
            else:
                s1 = self.conv1(xc[i])
                s_out = self.conv2(torch.cat((xc[i], s1), dim=1))
            out.append(s_out)

        out = self.aggr(torch.cat(out, dim=1))
        out = self.lrelu(out) * x
        return out
class CCM(nn.Module):
    def __init__(self, dim, bias=True):
        super().__init__()
        self.conv1 = nn.Conv2d(dim, dim * 2, 3, 1, 1, bias=bias)
        self.conv2 = nn.Conv2d(dim * 2, dim, 1, 1, 0, bias=bias)
        self.lrelu = nn.LeakyReLU(inplace=True)
        # mutil.initialize_weights([self.conv2], 0.)
    def forward(self, x):
        out = self.lrelu(self.conv1(x))
        out = self.conv2(out)
        return out
class FMM(nn.Module):
    def __init__(self, input, DWT=True, bias=True):
        super().__init__()
        self.safm = SAFM(input, DWT=DWT, bias=bias)
        self.ccm = CCM(input, bias=bias)
    def forward(self, x):
        out = self.safm(x) + x
        out = self.ccm(out) + out
        return out


# class ResidualDenseBlock_out(nn.Module):Feature Mixing guided Dense Block
#     def __init__(self, input, output, DWT=True, bias=True, FMDB_channel=32):
#         super(ResidualDenseBlock_out, self).__init__()
#         self.conv = nn.Conv2d(input, input + FMDB_channel, 1, 1, 0, bias=bias)
#         self.conv1 = nn.Conv2d(input, FMDB_channel, 3, 1, 1, bias=bias)
#         self.fmm = FMM(input + FMDB_channel, DWT=DWT, bias=bias) #44
#         self.conv2 = nn.Conv2d(input + FMDB_channel, output, 3, 1, 1, bias=bias)
#         self.lrelu = nn.LeakyReLU(inplace=True)
#         mutil.initialize_weights([self.conv2], 0.)
#     def forward(self, x):
#         x1 = self.lrelu(self.conv1(x))
#         fmm = self.fmm(torch.cat((x, x1), 1))
#         fmm = fmm + self.lrelu(self.conv(x))
#         x5 = self.conv2(fmm)
#         return x5



class ResidualDenseBlock_out(nn.Module):#Watermark-oriented Feature-Mixing-guided DenseBlock
    def __init__(self, input, output, DWT=True, bias=True, FMDB_channel=32):
        super(ResidualDenseBlock_out, self).__init__()
        self.conv1 = nn.Conv2d(input, FMDB_channel, 3, 1, 1, bias=bias)
        self.fmm = FMM(input + FMDB_channel, DWT=DWT, bias=bias) #44
        self.conv2 = nn.Conv2d(input + FMDB_channel, output, 3, 1, 1, bias=bias)
        self.lrelu = nn.LeakyReLU(inplace=True)

        # 残差连接适配：确保输入x能直接与输出x5相加（通道数一致）
        if input != output:
            self.residual_adjust = nn.Conv2d(input, output, 1, 1, 0, bias=bias)  # 通道不一致时用1x1卷积适配
        else:
            self.residual_adjust = nn.Identity()  # 通道一致时直接恒等映射
        # mutil.initialize_weights([self.conv2], 0.)

    def forward(self, x):
        x1 = self.lrelu(self.conv1(x))  # 输入特征降维激活
        x_concat = torch.cat((x, x1), 1)  # 输入x与x1拼接（通道数：input + FMDB_channel）
        fmm_out = self.fmm(x_concat)  # FMM特征融合
        # 移除冗余的 "fmm + conv(x)"：避免放大噪声
        main_out = self.conv2(fmm_out)  # 主分支最终输出

        # 残差分支：输入x对齐后与主分支输出相加
        residual_out = self.residual_adjust(x)  # 适配输入x的通道数
        final_out = main_out + residual_out  # 残差连接：特征对齐融合
        return final_out
