import torch
import torch.optim
import torch.nn as nn
from network.inn import INN

class ImageViewLayer(nn.Module):
    def __init__(self, diffusion_size=16, channel=3):
        super().__init__()
        self.diffusion_size = diffusion_size
        self.channel = channel

    def forward(self, x):
        return x.view(-1, self.channel, self.diffusion_size, self.diffusion_size)
class InvImageViewLayer(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, x):
        return x.view(x.shape[0], -1)

class Watermark2Image(nn.Module):
    def __init__(self, watermark_length = 128, diffusion_length = 256, Norm='', MLP_smooth = True):# B 3 16 16     16*(2**4)
        super().__init__()
        self.diffusion_size = int(diffusion_length ** 0.5)
        if MLP_smooth:
            self.mid_dim = (watermark_length + diffusion_length * 3) // 2
        else:
            self.mid_dim = diffusion_length * 3 // 2
        self.Norm = Norm

        def norm_layer(channels):
            """根据Norm类型返回归一化层"""
            if self.Norm == 'BatchNorm2d':
                return nn.BatchNorm2d(channels)
            elif self.Norm == 'GroupNorm':
                return nn.GroupNorm(max(1, channels // 8), channels)
            else:
                return nn.Identity()
        if diffusion_length == 256:
            self.transform = nn.Sequential(
            nn.Linear(watermark_length, self.mid_dim),
            nn.LeakyReLU(0.2),
            nn.Linear(self.mid_dim, diffusion_length * 3),
            nn.LeakyReLU(0.2),
            ImageViewLayer(self.diffusion_size, 3),

            nn.ConvTranspose2d(3, 64, kernel_size=4, stride=2, padding=1),
            norm_layer(64),
            nn.LeakyReLU(0.2),

            nn.ConvTranspose2d(64, 32, kernel_size=4, stride=2, padding=1),
            norm_layer(32),
            nn.LeakyReLU(0.2),

            nn.ConvTranspose2d(32, 16, kernel_size=4, stride=2, padding=1),
            norm_layer(16),
            nn.LeakyReLU(0.2),

            nn.ConvTranspose2d(16, 3, kernel_size=4, stride=2, padding=1),
            nn.Tanh(),
        )
        elif diffusion_length == 1024:
            self.transform = nn.Sequential(
                nn.Linear(watermark_length, self.mid_dim),
                nn.LeakyReLU(0.2),
                nn.Linear(self.mid_dim, diffusion_length * 3),
                nn.LeakyReLU(0.2),
                ImageViewLayer(self.diffusion_size, 3),

                nn.ConvTranspose2d(3, 64, kernel_size=4, stride=2, padding=1),
                norm_layer(64),
                nn.LeakyReLU(0.2),

                nn.ConvTranspose2d(64, 32, kernel_size=4, stride=2, padding=1),
                norm_layer(32),
                nn.LeakyReLU(0.2),

                nn.ConvTranspose2d(32, 3, kernel_size=4, stride=2, padding=1),
                nn.Tanh(),
            )

        elif diffusion_length == 4096:
            self.transform = nn.Sequential(
                nn.Linear(watermark_length, self.mid_dim),
                nn.LeakyReLU(0.2),
                nn.Linear(self.mid_dim, diffusion_length * 3),
                nn.LeakyReLU(0.2),
                ImageViewLayer(self.diffusion_size, 3),

                nn.ConvTranspose2d(3, 64, kernel_size=4, stride=2, padding=1),
                norm_layer(64),
                nn.LeakyReLU(0.2),

                nn.ConvTranspose2d(64, 3, kernel_size=4, stride=2, padding=1),
                nn.Tanh(),
            )
    def forward(self, x):
        return self.transform(x)
class Image2Watermark(nn.Module):
    def __init__(self, watermark_length=128, diffusion_length=256, Norm='', MLP_smooth = True): #
        super().__init__()
        if MLP_smooth:
            self.mid_dim = (watermark_length + diffusion_length * 3) // 2
        else:
            self.mid_dim = diffusion_length * 3 // 2

        self.Norm = Norm
        def norm_layer(channels):
            """根据Norm类型返回归一化层"""
            if self.Norm == 'BatchNorm2d':
                return nn.BatchNorm2d(channels)
            elif self.Norm == 'GroupNorm':
                return nn.GroupNorm(max(1, channels // 8), channels)
            else:
                return nn.Identity()
        if diffusion_length==256:
            self.inv_transform = nn.Sequential(
            nn.Conv2d(3, 16, kernel_size=4, stride=2, padding=1),
            norm_layer(16),
            nn.LeakyReLU(0.2),

            nn.Conv2d(16, 32, kernel_size=4, stride=2, padding=1),
            norm_layer(32),
            nn.LeakyReLU(0.2),

            nn.Conv2d(32, 64, kernel_size=4, stride=2, padding=1),
            norm_layer(64),
            nn.LeakyReLU(0.2),

            nn.Conv2d(64, 3, kernel_size=4, stride=2, padding=1),
            norm_layer(3),
            nn.LeakyReLU(0.2),

            InvImageViewLayer(),
            nn.Linear(diffusion_length * 3, self.mid_dim),
            nn.LeakyReLU(0.2),
            nn.Linear(self.mid_dim, watermark_length),
            nn.Tanh()
        )
        elif diffusion_length==1024:
            self.inv_transform = nn.Sequential(
                nn.Conv2d(3, 32, kernel_size=4, stride=2, padding=1),
                norm_layer(32),
                nn.LeakyReLU(0.2),

                nn.Conv2d(32, 64, kernel_size=4, stride=2, padding=1),
                norm_layer(64),
                nn.LeakyReLU(0.2),

                nn.Conv2d(64, 3, kernel_size=4, stride=2, padding=1),
                norm_layer(3),
                nn.LeakyReLU(0.2),

                InvImageViewLayer(),
                nn.Linear(diffusion_length * 3, self.mid_dim),
                nn.LeakyReLU(0.2),
                nn.Linear(self.mid_dim, watermark_length),
                nn.Tanh()
            )
        elif diffusion_length==4096:
            self.inv_transform = nn.Sequential(
                nn.Conv2d(3, 64, kernel_size=4, stride=2, padding=1),
                norm_layer(64),
                nn.LeakyReLU(0.2),

                nn.Conv2d(64, 3, kernel_size=4, stride=2, padding=1),
                norm_layer(3),
                nn.LeakyReLU(0.2),

                InvImageViewLayer(),
                nn.Linear(diffusion_length * 3, self.mid_dim),
                nn.LeakyReLU(0.2),
                nn.Linear(self.mid_dim, watermark_length),
                nn.Tanh()
            )

    def forward(self, x):
        return self.inv_transform(x)








class Models(nn.Module):
    def __init__(self, Norm='', MLP_smooth=True, watermark_length=128, diffusion_length=256, num_blocks=8, harr=True, bias=True, FMDB_channel=32):
        super(Models, self).__init__()
        self.harr = harr
        self.inn = INN(num_blocks=num_blocks, harr=harr, bias=bias, FMDB_channel=FMDB_channel)
        self.wtoi = Watermark2Image(watermark_length=watermark_length, diffusion_length=diffusion_length, Norm=Norm, MLP_smooth=MLP_smooth)
        self.itow = Image2Watermark(watermark_length=watermark_length, diffusion_length=diffusion_length, Norm=Norm, MLP_smooth=MLP_smooth)

    def model_inn(self, x, rev=False):
        if not rev:
            out = self.inn(x)
        else:
            out = self.inn(x, rev=True)

        return out

    def model_wtoi(self, x):

        return self.wtoi(x)

    def model_itow(self, x):

        return self.itow(x)


def init_model(mod):
    """只对Hinet主模型进行初始化，不影响model_en和model_de"""
    for key, param in mod.named_parameters():
        # 只处理model部分的参数，跳过model_en和model_de
        if key.startswith('model.') and param.requires_grad:
            split = key.split('.')
            param.data = 0.01 * torch.randn(param.data.shape).cuda()
            if len(split) > 2 and split[-2] == 'conv5':
                param.data.fill_(0.)
    # print("只对inn模型进行了初始化，w i保持原样")

