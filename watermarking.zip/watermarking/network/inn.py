
import torch
import torch.nn as nn
from network.rrdb_denselayer import ResidualDenseBlock_out

class INV_block(nn.Module):
    def __init__(self, subnet_constructor=ResidualDenseBlock_out, clamp=2.0, harr=True, bias=True, FMDB_channel=32, in_1=3, in_2=3):
        super().__init__()
        if harr:
            self.split_len1 = in_1 * 4
            self.split_len2 = in_2 * 4
        else:
            self.split_len1 = in_1
            self.split_len2 = in_2
        self.clamp = clamp
        # ρ
        self.r = subnet_constructor(self.split_len1, self.split_len2, bias=bias, FMDB_channel=FMDB_channel)
        # η
        self.y = subnet_constructor(self.split_len1, self.split_len2, bias=bias, FMDB_channel=FMDB_channel)
        # φ
        self.f = subnet_constructor(self.split_len2, self.split_len1, bias=bias, FMDB_channel=FMDB_channel)

    def e(self, s):
        return torch.exp(self.clamp * 2 * (torch.sigmoid(s) - 0.5))

    def forward(self, x, rev=False):
        x1, x2 = (x.narrow(1, 0, self.split_len1),
                  x.narrow(1, self.split_len1, self.split_len2))

        if not rev:

            t2 = self.f(x2)
            y1 = x1 + t2
            s1, t1 = self.r(y1), self.y(y1)
            y2 = self.e(s1) * x2 + t1

        else:
            s1, t1 = self.r(x1), self.y(x1)
            y2 = (x2 - t1) / self.e(s1)
            t2 = self.f(y2)
            y1 = (x1 - t2)

        return torch.cat((y1, y2), 1)


class INN(nn.Module):
    def __init__(self, num_blocks=8, harr=True, bias=True, FMDB_channel=32):  # 可配置的block数量
        super().__init__()
        self.num_blocks = num_blocks
        self.inv_blocks = nn.ModuleList([INV_block(harr=harr, bias=bias, FMDB_channel=FMDB_channel) for _ in range(self.num_blocks)])# 使用ModuleList管理多个INV_block

    def forward(self, x, rev=False):
        blocks = self.inv_blocks if not rev else reversed(self.inv_blocks)

        for block in blocks:
            if rev:
                x = block(x, rev=True)
            else:
                x = block(x)

        return x
