import torch
from network.Noise import Noise

from main import main
if __name__ == "__main__":
    torch.backends.cudnn.benchmark = True
    torch.backends.cudnn.deterministic = False
    main_mode = 'train'

    if main_mode == 'train':
        from utils.load_train_setting import *
        perceived_attack_layers = Noise(perceived_attack_layers)
        attack_layers = Noise(attack_layers)

        for step in range(3):
            anzhaoxuqiuxuan=1
            # if step == 0:
            #     main(main_mode, train_continue, project_name_continue, result_folder, step, 1, 0, 3000, perceived_attack_layers, attack_layers)
            if step == 1:
                main(main_mode, train_continue, project_name_continue, result_folder, step, 1, 3000, 6000, perceived_attack_layers, attack_layers, '1')
                # main(main_mode, train_continue, project_name_continue, result_folder, step, 1, 3000, 6000,perceived_attack_layers, attack_layers, '1', only_load_wtoi_itow)




            # if step == 2:
            #     main(main_mode, result_folder, step, strength, 2000, 4500, perceived_attack_layers, attack_layers, '1')
