from .settings import *
import os
import time

'''
params setting
'''
filename = "./utils/test_settings.json"
settings = Config()
settings.load_json_file(filename)



perceived_attack_layers = settings.perceived_attack_layers
attack_layers = settings.attack_layers
result_folder = "results/" + settings.result_folder
train_continue = False
project_name_continue = ''
only_load_wtoi_itow=False
if not os.path.exists(result_folder + f"test_results/"): os.mkdir(result_folder + f"test_results/")
if not os.path.exists(result_folder + f"test_results/step0/"): os.mkdir(result_folder + f"test_results/step0/")
if not os.path.exists(result_folder + f"test_results/step1/"): os.mkdir(result_folder + f"test_results/step1/")
if not os.path.exists(result_folder + f"test_results/step1/original/"): os.mkdir(result_folder + f"test_results/step1/original/")
if not os.path.exists(result_folder + f"test_results/step1/watermarked/"): os.mkdir(result_folder + f"test_results/step1/watermarked/")
if not os.path.exists(result_folder + f"test_results/step1/noised/"): os.mkdir(result_folder + f"test_results/step1/noised/")
if not os.path.exists(result_folder + f"test_results/step1/secret/"): os.mkdir(result_folder + f"test_results/step1/secret/")
if not os.path.exists(result_folder + f"test_results/step1/secret-rev/"): os.mkdir(result_folder + f"test_results/step1/secret-rev/")

if not os.path.exists(result_folder + f"test_results/step2/"): os.mkdir(result_folder + f"test_results/step2/")
if not os.path.exists(result_folder + f"test_results/step2/original/"): os.mkdir(result_folder + f"test_results/step2/original/")
if not os.path.exists(result_folder + f"test_results/step2/watermarked/"): os.mkdir(result_folder + f"test_results/step2/watermarked/")
if not os.path.exists(result_folder + f"test_results/step2/noised/"): os.mkdir(result_folder + f"test_results/step2/noised/")
if not os.path.exists(result_folder + f"test_results/step2/secret/"): os.mkdir(result_folder + f"test_results/step2/secret/")
if not os.path.exists(result_folder + f"test_results/step2/secret-rev/"): os.mkdir(result_folder + f"test_results/step2/secret-rev/")


# with open(result_folder + f"/test_{attack_layers}_log.txt", "w") as file:
# 	content = "-----------------------" + time.strftime("Date: %Y/%m/%d %H:%M:%S",
# 														time.localtime()) + "-----------------------\n"
# 	file.write(content)

# with open(result_folder + "/test_C_allepoch_log.txt", "w") as file:
# 	content = "-----------------------" + time.strftime("Date: %Y/%m/%d %H:%M:%S",
# 														time.localtime()) + "-----------------------\n"
# 	file.write(content)
#
# with open(result_folder + "/test_Jpeg_allepoch_log.txt", "w") as file:
# 	content = "-----------------------" + time.strftime("Date: %Y/%m/%d %H:%M:%S",
# 														time.localtime()) + "-----------------------\n"
# 	file.write(content)

import config as c
config_attrs = []#获取config模块的所有属性
for name in dir(c):
	if not name.startswith('_'):  # 跳过私有属性
		value = getattr(c, name)
		config_attrs.append((name, value))

with open(result_folder + "/test_params.txt", "w") as file:
	# 第一部分：时间和settings内容
	content = "-----------------------" + time.strftime("Date: %Y/%m/%d %H:%M:%S",
														time.localtime()) + "-----------------------\n"

	for item in settings.get_items():
		content += item[0] + " = " + str(item[1]) + "\n"

	print(content)
	file.write(content)

	# 第二部分：config参数
	config_content = "\n=== ceshi配置参数 ===\n"
	for name, value in config_attrs:
		config_content += f"{name}: {value}\n"
	config_content += "=" * 30 + "\n\n"

	file.write(config_content)
	print(config_content)  # 也打印config内容
	print("配置参数已自动保存到", result_folder + "/test_params.txt")
