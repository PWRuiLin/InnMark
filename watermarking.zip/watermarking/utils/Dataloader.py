import os
from PIL import Image
# import numpy as np
# import random
# import torch
from torchvision import transforms
# from torch.utils import data
from torch.utils.data import Dataset

class Dataset(Dataset):
    """图像数据集类"""

    def __init__(self, path, H=256, W=256, train=True):
        super(Dataset, self).__init__()
        self.H = H
        self.W = W
        self.path = path
        self.list = [f for f in os.listdir(path) if f.lower().endswith(('.png', '.jpg', '.jpeg'))]
        if train:
            self.transform = transforms.Compose([
                # transforms.Resize((int(self.H * 1.1), int(self.W * 1.1))),
                # transforms.RandomCrop((self.H, self.W)),
                # transforms.CenterCrop((800, 800)),
                transforms.Resize((int(self.H), int(self.W))),
                transforms.ToTensor(),
                transforms.Normalize([0.5, 0.5, 0.5], [0.5, 0.5, 0.5])
            ])
        else:
            self.transform = transforms.Compose([
                # transforms.Resize((int(self.H * 1.1), int(self.W * 1.1))),
                # transforms.RandomCrop((self.H, self.W)),
                transforms.ToTensor(),
                transforms.Normalize([0.5, 0.5, 0.5], [0.5, 0.5, 0.5])
            ])

    def transform_image(self, image):
        """图像预处理"""
        # 忽略过小的图像
        if image.size[0] < self.W / 2 and image.size[1] < self.H / 2:
            return None
        if image.size[0] < image.size[1] / 2 or image.size[1] < image.size[0] / 2:
            return None

        # 数据增强、转换为张量和归一化
        image = self.transform(image)
        return image

    def __getitem__(self, index):
        """获取数据项"""
        while True:
            try:
                image_path = os.path.join(self.path, self.list[index])
                image = Image.open(image_path).convert("RGB")
                image = self.transform_image(image)
                if image is not None:
                    return image
                index = (index + 1) % len(self.list)
            except Exception as e:
                print(f"加载图像 {self.list[index]} 时出错: {e}")
                index = (index + 1) % len(self.list)

    def __len__(self):
        """数据集长度"""
        return len(self.list)


import glob
class Dataset_glob(Dataset):
    """图像数据集类"""

    def __init__(self, path, H=256, W=256, train=True):
        super(Dataset, self).__init__()
        self.H = H
        self.W = W
        self.path = path
        self.path = path
        # 递归查找所有子文件夹中的图片
        self.list = glob.glob(os.path.join(path, '**', '*.*'), recursive=True)
        # 过滤图片格式
        self.list = [f for f in self.list if f.lower().endswith(('.png', '.jpg', '.jpeg'))]

        # self.list = [f for f in os.listdir(path) if f.lower().endswith(('.png', '.jpg', '.jpeg'))]
        if train:
            self.transform = transforms.Compose([
                # transforms.Resize((int(self.H * 1.1), int(self.W * 1.1))),
                # transforms.RandomCrop((self.H, self.W)),
                # transforms.CenterCrop((800, 800)),
                transforms.Resize((int(self.H), int(self.W))),
                transforms.ToTensor(),
                transforms.Normalize([0.5, 0.5, 0.5], [0.5, 0.5, 0.5])
            ])
        else:
            self.transform = transforms.Compose([
                # transforms.Resize((int(self.H * 1.1), int(self.W * 1.1))),
                # transforms.RandomCrop((self.H, self.W)),
                transforms.ToTensor(),
                transforms.Normalize([0.5, 0.5, 0.5], [0.5, 0.5, 0.5])
            ])

    def transform_image(self, image):
        """图像预处理"""
        # 忽略过小的图像
        if image.size[0] < self.W / 2 and image.size[1] < self.H / 2:
            return None
        if image.size[0] < image.size[1] / 2 or image.size[1] < image.size[0] / 2:
            return None

        # 数据增强、转换为张量和归一化
        image = self.transform(image)
        return image

    def __getitem__(self, index):
        """获取数据项"""
        while True:
            try:
                # image_path = os.path.join(self.path, self.list[index])
                image_path = self.list[index]  # 直接使用完整路径

                image = Image.open(image_path).convert("RGB")
                image = self.transform_image(image)
                if image is not None:
                    return image
                index = (index + 1) % len(self.list)
            except Exception as e:
                print(f"加载图像 {self.list[index]} 时出错: {e}")
                index = (index + 1) % len(self.list)

    def __len__(self):
        """数据集长度"""
        return len(self.list)
