import torch
from network.Noise import Noise

from main import main
if __name__ == "__main__":
    torch.backends.cudnn.benchmark = True
    torch.backends.cudnn.deterministic = False
    main_mode = 'train'

    if main_mode == 'train':
        from utils.load_train_setting import *
        perceived_attack_layers = Noise(perceived_attack_layers)
        attack_layers = Noise(attack_layers)

        for step in range(3):
            # if step == 0:
            #     main(main_mode, train_continue, project_name_continue, result_folder, step, 1, 0, 3000, perceived_attack_layers, attack_layers)
            # if step == 1:
            #     main(main_mode, train_continue, project_name_continue, result_folder, step, 1, 3000, 4500, perceived_attack_layers, attack_layers, '1', only_load_wtoi_itow)
            if step == 2:
                train_continue=True
                main(main_mode, train_continue, project_name_continue, result_folder, step, 1, 7500, 8500, perceived_attack_layers, attack_layers, '1', only_load_wtoi_itow)



# HFlip = all.HorizontalFlip(p=1.0)
# VFlip = all.VerticalFlip(p=1.0)
# Rotation = all.Rotation(degrees=[0.0, 10.0], p=1.0) #degrees=[0.0, 10.0]
# Perspective = all.Perspective(distortion_scale=0.1, p=1.0)
# ResizedCrop = all.ResizedCrop(size=(256, 256), scale=(0.75, 1.0), ratio=(3.0 / 4.0, 4.0 / 3.0))

