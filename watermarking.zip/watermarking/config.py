import torch
device = torch.device(f"cuda:4")
# device = torch.device(f"cpu")

lamda_encoding = 1
lamda_decoding = 1
lamda_decoding_step2 = 0.1#2
# vggloss = False
# lamda_encoding1 = 1#20   No
# fflloss = False
# lamda_encoding2 = 1  #20
# pre_decoding = False
# lamda_decoding1 = 1


load_opt = False
#jpeg+cp      diffusion_length=256  #watermark_length=128 yixia:   3 he 3.5


#diffusion_length=256  #watermark_length=256  : 3.5 he 4
#diffusion_length=1024  #watermark_length=256 : 3.5 he 4

#diffusion_length=1024 #watermark_length=1024 : 4 he 4.5
#diffusion_length=4096 #watermark_length=1024 : 4 he 4.5
lr0 = 10 ** (-3)  # 10 ** (-3)
step_size0 = 50  # 100
gamma0 = 0.93  # 0.8

lr1 = 10 ** (-3.5)  # 10 ** (-4.5)#0.000316
step_size1 = 100  # 100
gamma1 = 0.93  # 0.8

#################################################zhiyou all noise caiyou step2
#jpeg+cp+hf+vf+r+p+rc     diffusion_length=1024  watermark_length=100:   3.3 he 3.8   zuihou 4.3
#jpeg+cp+hf+vf+r+p+rs     diffusion_length=1024  watermark_length=100:   3 he 3.5     zuihou 4.0
#jpeg+cp+hf+vf+r+p+rc     diffusion_length=256   watermark_length=100:   3 he 3.5     zuihou 4.0
#jpeg+cp+hf+vf+r+p+rs     diffusion_length=256   watermark_length=100:   3 he 3.5     zuihou 4.0
lr2 = 10 ** (-4)  # 10 ** (-4.5)#0.000316
step_size2 = 200  # 100
gamma2 = 0.93  # 0.8

# lr1 = 10 ** (-3)  # 10 ** (-3)
# step_size1 = 50  # 100
# gamma1 = 0.945  # 0.8


# lr2 = 10 ** (-5)#0.0000316
# step_size2 = 100
# gamma2 = 0.9

watermark_length=100               #0-256  256-1024
diffusion_length=256               #256    1024
num_blocks=4
FMDB_channel=32  #32 48
model_input_HW = 256#int(diffusion_length ** 0.5) *2 *2 *2 *2
Norm = 'GroupNorm'# '' 'BatchNorm2d' 'GroupNorm'
MLP_smooth = True
batch_size_train = 8












arbitrary_resolution = False

